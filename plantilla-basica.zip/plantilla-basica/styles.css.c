/* Este archivo está listo para cuando quieras personalizar más */
/* Por ahora, todo el estilo está en index.html para que sea más fácil */

/* Ejemplo: Si quieres cambiar el color del fondo después: */
/*
body {
    background: linear-gradient(135deg, #tu-color-1, #tu-color-2);
}
*/
