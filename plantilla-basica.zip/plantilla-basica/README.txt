🎨 CÓMO PERSONALIZAR TU PÁGINA

Paso 1: Abre este archivo
- Haz clic derecho en "index.html"
- Selecciona "Abrir con" → "Bloc de notas" (Windows) o "TextEdit" (Mac)

Paso 2: Busca y reemplaza estos textos:
✏️ [TU NOMBRE] → Tu nombre real
✏️ [Estudiante • Diseñador • Desarrollador] → Tu profesión o intereses
✏️ [Escribe algo sobre ti...] → Tu biografía (2-3 frases)
✏️ tu@email.com → Tu correo real
✏️ 💻 HTML/CSS, 🎨 Diseño... → Tus habilidades reales

Paso 3: Guarda los cambios
- En el Bloc de notas: Archivo → Guardar
- ¡Listo! No necesitas saber programación.

Paso 4: Sube a Vercel
1. Ve a https://vercel.com
2. Inicia sesión o crea cuenta gratis
3. Haz clic en "Add New..." → "Project"
4. Arrastra ESTA CARPETA completa al área indicada
5. Espera ~30 segundos y copia tu enlace .vercel.app

¿Problemas? Escríbenos: hola@tecnosofia.xyz

✨ Tip: Puedes cambiar el emoji 👤 por una foto tuya después.
   Busca en Google "cómo poner imagen en HTML" cuando quieras avanzar.
